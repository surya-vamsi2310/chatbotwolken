## intent:goodbye  
- Bye 
- Goodbye
- See you later
- Bye bot
- Goodbye friend
- bye
- bye for now
- catch you later
- gotta go
- See you
- goodnight
- have a nice day
- i'm off
- see you later alligator
- we'll speak soon
- end
- finish

## intent:greet
- Hi
- Hey
- Hi bot
- Hey bot
- Hello
- Good morning
- hi again
- hi folks
- hi Mister
- hi pal!
- hi there
- greetings
- hello everybody
- hello is anybody there
- hello robot
- who are you?
- what are you?
- what's up
- how do you do?

## intent:thanks
- Thanks
- Thank you
- Thank you so much
- Thanks bot
- Thanks for that
- cheers
- cheers bro
- ok thanks!
- perfect thank you
- thanks a bunch for everything
- thanks for the help
- thanks a lot
- amazing, thanks
- cool, thanks
- cool thank you

## intent:affirm
- y
- Y
- yes
- yes sure
- absolutely
- for sure
- yes yes yes
- definitely
- yes, it did.

## intent:deny
- no
- never
- I don't think so
- don't like that
- no way
- not really
- n
- N

## intent:ticket_status
- what is my ticket status
- ticket status
- status of my ticket
- what is my status of my ticket
- what is status of my ticket
- can i know my ticket status
- what's my ticket status


## intent: small_talk
- nice to meet you
- nice meeting you
- It was nice to have met you
- glad to meet you
- pleased to meet you
- It has been a pleasure meeting you
- nice to see you
- great interacting with you

## intent: state
- How are you
- how are you doing
- how do you do
- Good morning! How are you
- how have you been doing
- Hi! How are you
- how are things going
- How is your day going
- how have you been lately

## intent: thank_u
- thank you
- thanks
- thank you for your help
- thanks for helping me
- thank you so much
- ok thank you
- i appreciate your help

## intent: whats_up
- whats going on
- whats up
- what is going on
- hey, whats up
- what's happening
- what are you doing now
- what are your plans today

## intent: compliment
- wow you are great
- you are awesome
- that's awesome
- you are fantastic
- you are smart
- you are smarter than me

## intent: welcomed
- you are welcomed
- you are welcome
- It is my pleasure
- pleasure is mine
- Its my pleasure

## intent: positive
- do you like talking to me
- do you like human
- are you intelligent
- are you smart
- are you shy

## intent: negative
- are you alien
- do you hate me
- Can you feel anything
- Can you feel pain
- do you have feelings
- Are you tired

## intent: rude
- ass
- stupid
- dickhead
- cunt
- asshole
- piece of shit
- dumb ass
- fuck off
- bitch
- whore

## intent: hobby
- do you have any hobby
- do you have any hobbies
- what's your favourite hobby
- What is your favourite hobby
- what hobbies do you have
- How do you spend your time
- what are your hobbies
- what do you like doing

## intent: positive_greet
- Not bad
- just chilling
- marvellous
- super
- awesome
- cool
- perfect
- fabulous
- I am cool
- My day is fantastic thank you
- Very well, thanks
- going great
- I am feeling great
- I am doing great
- great. thanks for asking

## intent: negative_greet
- bad
- bad mood
- i am in a bad mood
- sad
- i am sad
- i feel sad
- feeling sad
- i am feeling sad
- i am feeling bad
- terrible
- broken
- not so well today
- unhealthy
- today is my worst day
- i got dumped today
- i was fired today
- i was sick today
- i have a fever

