import re

print(re.findall('\d{4,}', '1234567'))
